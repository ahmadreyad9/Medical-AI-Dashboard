
import os
import io
import time
import pandas as pd
import numpy as np
import streamlit as st
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import plotly.express as px
import joblib

D_PATH = os.path.join("data", "patients.csv")
M_PATH = os.path.join("models", "diabetes_model.pkl")

st.set_page_config(page_title="Virtual Medical AI Dashboard", layout="wide")

@st.cache_data
def load_data() -> pd.DataFrame:
    """Load patients dataset, generate a realistic sample if missing."""
    if os.path.exists(D_PATH):
        df = pd.read_csv(D_PATH)
    else:
        np.random.seed(42)
        n = 350
        gender = np.random.choice(["Male", "Female"], size=n)
        age = np.random.normal(45, 14, size=n).clip(18, 85).round().astype(int)
        bmi = np.random.normal(27, 5.5, size=n).clip(16, 48).round(1)
        glucose = np.random.normal(120, 30, size=n).clip(70, 260).round(0)
        bp = np.random.normal(78, 12, size=n).clip(45, 120).round(0)
        insulin = np.random.normal(80, 35, size=n).clip(10, 250).round(0)
        pregnancies = (np.random.poisson(2, size=n) * (gender == "Female")).astype(int)
        smoke = np.random.choice(["Yes", "No"], size=n, p=[0.22, 0.78])

        # quick way to make a fake risk label
        rule = (glucose > 130).astype(int) + (bmi > 32).astype(int) + (age > 50).astype(int)
        noise = np.random.binomial(1, 0.08, size=n)
        risk = ((rule + noise) > 0).astype(int)

        diagnosis = np.where(risk == 1, "Diabetes", "Healthy")

        df = pd.DataFrame({
            "PatientID": np.arange(1, n + 1),
            "Name": [f"Patient {i}" for i in range(1, n + 1)],
            "Age": age,
            "Gender": gender,
            "BMI": bmi,
            "Glucose": glucose,
            "BloodPressure": bp,
            "Insulin": insulin,
            "Pregnancies": pregnancies,
            "Smoker": smoke,
            "Diagnosis": diagnosis,
            "DiabetesRisk": risk
        })

        os.makedirs("data", exist_ok=True)
        df.to_csv(D_PATH, index=False)
    return df

def save_data(df: pd.DataFrame):
    os.makedirs("data", exist_ok=True)
    df.to_csv(D_PATH, index=False)

def train_model(df: pd.DataFrame):
    features = ["Age", "BMI", "Glucose", "BloodPressure"]
    target = "DiabetesRisk"
    X = df[features].values
    y = df[target].values

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)

    clf = Pipeline([
        ("scaler", StandardScaler()),
        ("logreg", LogisticRegression(max_iter=1000))
    ])

    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    y_proba = clf.predict_proba(X_test)[:, 1]

    metrics = {
        "Accuracy": float(accuracy_score(y_test, y_pred)),
        "Precision": float(precision_score(y_test, y_pred, zero_division=0)),
        "Recall": float(recall_score(y_test, y_pred, zero_division=0)),
        "F1": float(f1_score(y_test, y_pred, zero_division=0)),
        "ConfusionMatrix": confusion_matrix(y_test, y_pred).tolist()
    }

    os.makedirs("models", exist_ok=True)
    joblib.dump(clf, M_PATH)

    return clf, metrics

def predict_single(clf, age, bmi, glucose, bp):
    X = np.array([[age, bmi, glucose, bp]])
    proba = float(clf.predict_proba(X)[0, 1])
    label = "High Risk" if proba >= 0.5 else "Low Risk"
    return label, proba

def header():
    st.title("Virtual Medical AI Dashboard")
    st.caption("Demo dashboard for managing patient data, analytics, and simple ML risk prediction.")

df = load_data()

with st.sidebar:
    st.header("Navigation")
    page = st.radio("Go to", ["Home", "Patients", "Analytics", "ML Model", "Settings"], index=0)
    st.markdown("---")
    st.write("Data file:", f"`{D_PATH}`")
    st.write("Model file:", f"`{M_PATH}`")

header()

# -------------------- HOME --------------------
if page == "Home":
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Patients", f"{len(df):,}")
    c2.metric("Avg. Age", f"{df['Age'].mean():.1f}")
    c3.metric("Avg. BMI", f"{df['BMI'].mean():.1f}")
    c4.metric("Diabetes Risk %", f"{df['DiabetesRisk'].mean()*100:.1f}%")

    st.markdown("### Quick Charts")
    col1, col2 = st.columns(2)
    with col1:
        gender_counts = df["Gender"].value_counts().reset_index()
        gender_counts.columns = ["Gender", "Count"]
        fig_gender = px.pie(gender_counts, names="Gender", values="Count", title="Gender Distribution")
        st.plotly_chart(fig_gender, use_container_width=True)
    with col2:
        dx_counts = df["Diagnosis"].value_counts().reset_index()
        dx_counts.columns = ["Diagnosis", "Count"]
        fig_dx = px.bar(dx_counts, x="Diagnosis", y="Count", title="Diagnosis Breakdown")
        st.plotly_chart(fig_dx, use_container_width=True)

    st.markdown("### Recent Records")
    st.dataframe(df.head(50))

# -------------------- PATIENTS --------------------
elif page == "Patients":
    st.subheader("Patients Registry")
    st.write("Add, edit, or import patient records. Use the actions below to manage the dataset.")

    with st.expander("➕ Add New Patient"):
        with st.form("add_form", clear_on_submit=True):
            name = st.text_input("Name")
            age = st.number_input("Age", min_value=0, max_value=120, value=35, step=1)
            gender = st.selectbox("Gender", ["Male", "Female"])
            bmi = st.number_input("BMI", min_value=10.0, max_value=60.0, value=26.0, step=0.1)
            glucose = st.number_input("Glucose", min_value=40.0, max_value=400.0, value=110.0, step=1.0)
            bp = st.number_input("Blood Pressure", min_value=30.0, max_value=200.0, value=80.0, step=1.0)
            insulin = st.number_input("Insulin", min_value=0.0, max_value=400.0, value=70.0, step=1.0)
            pregnancies = st.number_input("Pregnancies (0 for Male)", min_value=0, max_value=20, value=0, step=1)
            smoker = st.selectbox("Smoker", ["No", "Yes"])

            # fake risk score, just for demo
            risk = int((glucose >= 130) or (bmi >= 32) or (age >= 50))
            diagnosis = "Diabetes" if risk == 1 else "Healthy"

            submitted = st.form_submit_button("Add patient")
            if submitted:
                new_row = {
                    "PatientID": int(df["PatientID"].max() + 1 if len(df) else 1),
                    "Name": name or f"Patient {int(df['PatientID'].max() + 1 if len(df) else 1)}",
                    "Age": int(age),
                    "Gender": gender,
                    "BMI": float(bmi),
                    "Glucose": float(glucose),
                    "BloodPressure": float(bp),
                    "Insulin": float(insulin),
                    "Pregnancies": int(pregnancies),
                    "Smoker": smoker,
                    "Diagnosis": diagnosis,
                    "DiabetesRisk": int(risk)
                }
                df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
                save_data(df)
                st.success("Patient added successfully.")

    st.markdown("#### Edit Table")
    edited_df = st.data_editor(
        df,
        use_container_width=True,
        num_rows="dynamic",
        key="editor"
    )
    if st.button("💾 Save changes"):
        df = edited_df.copy()
        save_data(df)
        st.success("Dataset saved.")

    st.markdown("#### Import / Export")
    c1, c2 = st.columns(2)
    with c1:
        uploaded = st.file_uploader("Upload CSV", type=["csv"])
        if uploaded is not None:
            df = pd.read_csv(uploaded)
            save_data(df)
            st.success("CSV imported and saved.")
    with c2:
        csv_bytes = df.to_csv(index=False).encode("utf-8")
        st.download_button("Download current CSV", csv_bytes, file_name="patients.csv", mime="text/csv")

# -------------------- ANALYTICS --------------------
elif page == "Analytics":
    st.subheader("Analytics & Reports")

    tabs = st.tabs(["Distributions", "Correlations", "Custom Query"])

    with tabs[0]:
        col1, col2 = st.columns(2)
        with col1:
            fig_age = px.histogram(df, x="Age", nbins=30, title="Age Distribution")
            st.plotly_chart(fig_age, use_container_width=True)
        with col2:
            fig_bmi = px.histogram(df, x="BMI", nbins=30, title="BMI Distribution")
            st.plotly_chart(fig_bmi, use_container_width=True)
        col3, col4 = st.columns(2)
        with col3:
            fig_glu = px.histogram(df, x="Glucose", nbins=30, title="Glucose Distribution")
            st.plotly_chart(fig_glu, use_container_width=True)
        with col4:
            fig_bp = px.histogram(df, x="BloodPressure", nbins=30, title="Blood Pressure Distribution")
            st.plotly_chart(fig_bp, use_container_width=True)

    with tabs[1]:
        st.write("Scatter relationships")
        col1, col2 = st.columns(2)
        with col1:
            fig1 = px.scatter(df, x="BMI", y="Glucose", color="DiabetesRisk", title="BMI vs Glucose")
            st.plotly_chart(fig1, use_container_width=True)
        with col2:
            fig2 = px.scatter(df, x="Age", y="BloodPressure", color="DiabetesRisk", title="Age vs Blood Pressure")
            st.plotly_chart(fig2, use_container_width=True)

    with tabs[2]:
        st.write("Filter and summarize records")
        gender = st.multiselect("Gender", sorted(df["Gender"].unique().tolist()), default=None)
        diag = st.multiselect("Diagnosis", sorted(df["Diagnosis"].unique().tolist()), default=None)
        fdf = df.copy()
        if gender:
            fdf = fdf[fdf["Gender"].isin(gender)]
        if diag:
            fdf = fdf[fdf["Diagnosis"].isin(diag)]
        st.dataframe(fdf, use_container_width=True)
        st.write(f"Total records: {len(fdf)}")

# -------------------- ML MODEL --------------------
elif page == "ML Model":
    st.subheader("Diabetes Risk Prediction (Demo)")

    c1, c2 = st.columns([2, 1])
    with c1:
        st.write("Train a simple model on the current dataset (features: Age, BMI, Glucose, BloodPressure).")
        clf, metrics = train_model(df)
        st.success("Model trained and saved.")
        ms, acc = st.columns(2)
        with ms:
            st.json(metrics)
        with acc:
            cm = np.array(metrics["ConfusionMatrix"])
            st.write("Confusion Matrix")
            st.dataframe(pd.DataFrame(cm, index=["Actual 0", "Actual 1"], columns=["Pred 0", "Pred 1"]))
        st.download_button("Download trained model (.pkl)", data=open(M_PATH, "rb").read(), file_name="diabetes_model.pkl")

    with c2:
        st.markdown("**Try a prediction**")
        age = st.number_input("Age", 18, 100, 40)
        bmi = st.number_input("BMI", 10.0, 60.0, 28.0, step=0.1)
        glucose = st.number_input("Glucose", 40.0, 400.0, 120.0, step=1.0)
        bp = st.number_input("Blood Pressure", 30.0, 200.0, 80.0, step=1.0)

        if st.button("Predict risk"):
            label, proba = predict_single(clf, age, bmi, glucose, bp)
            st.metric("Prediction", label)
            st.metric("Probability of Diabetes", f"{proba*100:.1f}%")

# -------------------- SETTINGS --------------------
elif page == "Settings":
    st.subheader("Settings & Utilities")
    st.write("Manage data files and reset to sample dataset if needed.")
    if st.button("Reset to sample dataset"):
        if os.path.exists(D_PATH):
            os.remove(D_PATH)
        st.cache_data.clear()
        df = load_data()
        st.success("Dataset reset to generated sample.")
        st.dataframe(df.head())
    st.write("App version: 1.0.0")
